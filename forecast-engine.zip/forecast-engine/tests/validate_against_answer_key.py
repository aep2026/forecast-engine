"""
Independent check of the cleaning pipeline against the generator's hidden answer key.
This is a TEST, not part of the pipeline: the pipeline never reads the answer key.

    python tests/validate_against_answer_key.py
"""
from pathlib import Path
import numpy as np
import pandas as pd

base = Path(__file__).resolve().parents[1]
clean = pd.read_parquet(base / "data/clean/fact_pnl_clean.parquet")
truth = pd.read_csv(base / "data/_answer_key/pnl_truth_clean.csv.gz", parse_dates=["date"])
measures = ["volume_units", "gross_sales_lc", "trade_spend_lc", "net_sales_lc", "cogs_lc", "ap_lc"]

# 1) Row coverage
key = ["country", "date", "sku_code"]
m = truth.merge(clean, on=key, how="outer", suffixes=("_true", "_clean"), indicator=True)
print("1) ROW COVERAGE")
print(f"   truth rows {len(truth):,} | clean rows {len(clean):,}")
print(f"   matched {(m._merge == 'both').sum():,} | only in truth {(m._merge == 'left_only').sum():,} "
      f"| only in clean {(m._merge == 'right_only').sum():,}")
lo = m[m._merge == "left_only"]
print(f"   truth rows missing from clean, by cause: "
      f"Chile Mar-Apr 2025 = {((lo.country == 'Chile') & lo.date.isin(pd.to_datetime(['2025-03-01','2025-04-01']))).sum()}, "
      f"other = {(~((lo.country == 'Chile') & lo.date.isin(pd.to_datetime(['2025-03-01','2025-04-01'])))).sum()}")

# 2) Cell accuracy on matched rows
b = m[m._merge == "both"]
print("\n2) CELL ACCURACY (matched rows)")
for c in measures:
    t, k = b[f"{c}_true"], b[f"{c}_clean"]
    filled = k.notna()
    exact = (abs(t - k) <= np.maximum(1.0, 1e-4 * abs(t)))[filled]
    print(f"   {c:15s} filled {filled.mean():7.2%} | correct when filled {exact.mean():8.4%} | wrong {(~exact).sum():,}")

# 3) Totals by year (EUR m) vs control totals
ct = pd.read_csv(base / "data/_answer_key/control_totals_by_year.csv", index_col="year")
ours = clean.groupby(clean.date.dt.year)["net_sales_eur"].sum()
cmp_ = pd.DataFrame({"truth_NS": ct["net_sales_eur"] / 1e6, "clean_NS": ours / 1e6})
cmp_["gap"] = cmp_.clean_NS - cmp_.truth_NS
print("\n3) NET SALES EUR m: clean vs answer key")
print(cmp_.round(2).to_string())
print("\n   Expected gap: Chile Mar-Apr 2025 (missing extract) + 21 rows where NS cannot be rebuilt.")
