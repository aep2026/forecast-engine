# Step 3 - Reusable cleaning pipeline: design note

**Files:** `forecast_engine/clean.py` (rules) + `cleaning.yaml` (facts). Run monthly: drop new raw files in `data/raw`, run `python forecast_engine/clean.py`, read `data/clean/run_report.xlsx`.

## How the v2 cleaning logic maps to the code

| v2 step | Code step | Notes |
|---|---|---|
| 1 Read raw + snapshot | 01 ingest | Cells read as-is (no type guessing); source file, sheet and Excel row kept on every row |
| 2 Column layout | 02 schema | Per-tab column map in config; missing/extra column = BLOCK |
| 3 Normalise text | 03 text | NFC, non-breaking spaces, trim |
| 5 Countries | 04 countries | **Moved before dates**: India's fiscal calendar comes from the country master |
| 4 Dates | 05 dates | Patterns per tab in priority order; day/month guard; latest month = provisional |
| 6 Text to numbers | 06 numbers | Locale per tab (override per country possible); tokens kept blank with a reason, never 0 |
| 7 Sign | 07 sign | Config sign + self-check against the data; negatives allowed and flagged |
| 8 Magnitude | 08 magnitude | x1000 fix only if exactly one value explains the gap; volume x price tie-breaker; approval queue above EUR 5m; COGS/A&P ratio bands catch locale misreads |
| 9 SKU mapping | 09 sku | Code map + validity dates; master attributes only after a logged decision; recode event flag |
| 10 Duplicates | 10 duplicates | Merge field by field (prefer original Excel numbers); conflicts quarantined, never summed |
| 11 Quarantine gate | 11 gate | HOLD in prototype; switch to BLOCK in production |
| 12 Exact recovery | 12 recover | GS - TS = NS only |
| 13 Reconcile to ledger | 13 reconcile | Hook ready; HOLD until consolidation control totals are supplied |
| 14 Publish + snapshot | 14 publish | Snapshot per extract month; separates **completeness changes** (FLAG) from **value restatements** (HOLD) |
| 15 Completeness grid | 15 grid | missing_extract / zero_sale / suspect_missing (sell-in vs panel sell-out band) / possibly_dormant |
| 16 Estimates | 16 estimate | Forecast-ready layer only, always flagged; provisional months down-weighted |
| 17 Overheads | 17 overheads | Header found by keyword; function aliases; allocated to SKUs by Net Sales share |
| 18 Submissions & external | 18 external | Outlooks stored by vintage; GROUP rows split; open years marked |
| 19 FX & flags | inside 14 | EUR at monthly rate + constant currency (2025); hyperinflation, inorganic, lifecycle, regime, hemisphere |
| 20 Run report | 20 report | Hard checks, row bridge, value bridge, key ratios, approval queue, issue log |

## Test results (independent check against the generator's hidden answer key)

- 290,432 of 290,772 true rows recovered; the 340 missing are exactly Chile Mar-Apr 2025 (flagged missing_extract).
- About 1.74 million filled cells: **0 wrong values**. Fill rates: money lines 99.99%, COGS/A&P/volume 99.4% (rest blank by design in the clean layer).
- Duplicates removed: 907 = 871 planted copies + 36 recode overlaps. All 3 x1000 errors repaired.
- Value bridge (raw -> clean) unexplained difference: EUR 0.000m.
- Forecast-ready estimates vs truth: COGS 1.3% and volume 1.4% median error; A&P 7.2% (lumpy by nature). Zero-sale fills: 0 of 6,856 wrong.

## Reusability tests

- **Next month:** an October 2026 extract with different random errors ran with no code or config change; all hard checks passed.
- **Restatement control:** first version raised 32 false alarms (cells blank in one extract, filled in the other). Fixed by separating completeness changes from value restatements. A planted 5% restatement (Germany May 2025) was caught exactly.

## Known limits (to state in the pitch)

- No ledger control totals: clean actuals are internally consistent but not signed off against consolidation.
- Single monthly FX rate: IAS 29 closing-rate translation for Argentina/Turkey needs a closing-rate table.
- About 0.6% of COGS/A&P/volume can only be estimated; these are labelled and excluded from reported actuals.
