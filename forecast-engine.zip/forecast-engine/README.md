# Outside-in P&L forecast & AI challenge engine

Capstone prototype (AI finance course, Week 6, Mastery level). **All data is synthetic**: "Hygea Group" is a fictional
EUR 5B home & hygiene company (30 brands, 300 SKUs, 30 countries). No real company or personal data.

**Problem.** Annual budgeting takes 1-3 months, involves the whole organisation, starts inside-out and carries
predictable departmental biases. **Prototype.** An outside-in forecast (market, share, inflation, commodities, FX)
that departments adjust, an engine that challenges every submission, and a live scenario app.

## Live app
`app.py` - the 2027 scenario room (Streamlit). Every slider change re-runs the same forecast model.

## Pipeline (run in this order; each step has a Colab notebook in `notebooks/`)
| Step | Module | Settings | Output |
|---|---|---|---|
| 1 Synthetic company + messy extracts | `forecast_engine/generate.py` | `config.yaml` | `data/raw/` |
| 3 Reusable cleaning pipeline | `forecast_engine/clean.py` | `cleaning.yaml` | `data/clean/`, run report |
| 4 Exploratory analysis (7 business questions) | `forecast_engine/explore.py` | `analysis.yaml` | `data/eda/` |
| 5 Forecast: LightGBM volume + driver P&L, backtest | `forecast_engine/forecast.py` | `forecast.yaml` | `data/forecast/` |
| 6 Challenge engine | `forecast_engine/challenge.py` | `challenge.yaml` | `data/challenge/` |
| 7 Scenario app data bundle | `forecast_engine/app_bundle.py` | - | `app_data/` |

Step 2 (Thinking-mode diagnosis) is a written document. Tests: `tests/validate_against_answer_key.py`.

## Run locally
```
pip install -r requirements.txt
streamlit run app.py
```
To rebuild everything from scratch: run the modules above in order, then `python forecast_engine/app_bundle.py`.
